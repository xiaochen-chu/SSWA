# include "Global.h" 
# include "Random.h"

int nreal;
int nbin;
int nobj;
int ncon;
int popsize;
int archive_size;
int archive_capacity;
double pcross_real;
double pcross_bin;
double pmut_real;
double pmut_bin;
double eta_c;
double eta_m;
int ngen;
int nbinmut;
int nrealmut;
int nbincross;
int nrealcross;
int *nbits;
double *min_realvar;
double *max_realvar;
double *min_binvar;
double *max_binvar;
int bitlength;
double *min_pf;
double *max_pf;
int I_number; 
int weight_size;
double *ideal_point;
int neval;
int currenteval;
double prob;
int nr;


double seed;
double oldrand[55];
int jrand;